<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JenisPekerjaanController extends Controller
{
    //
}
