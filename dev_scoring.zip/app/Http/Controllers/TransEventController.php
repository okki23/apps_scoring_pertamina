<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TransEventController extends Controller
{
    //
}
